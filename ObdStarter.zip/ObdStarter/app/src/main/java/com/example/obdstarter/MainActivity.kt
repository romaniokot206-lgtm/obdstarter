package com.example.obdstarter

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val client = ObdClient()
    private lateinit var info: TextView
    private var pollJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        val connect = Button(this).apply { text = "Підключити адаптер" }
        info = TextView(this).apply { textSize = 18f; text = "Не підключено" }
        root.addView(connect)
        root.addView(ScrollView(this).apply { addView(info) })
        setContentView(root)

        connect.setOnClickListener { pickDevice() }
    }

    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun pickDevice() {
        if (!hasBtPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
            return
        }
        val adapter: BluetoothAdapter? =
            (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        val devices: List<BluetoothDevice> = adapter?.bondedDevices?.toList().orEmpty()
        if (devices.isEmpty()) {
            info.text = "Немає спарених пристроїв. Спершу спаруйте адаптер у налаштуваннях Bluetooth."
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Оберіть адаптер")
            .setItems(devices.map { "${it.name} (${it.address})" }.toTypedArray()) { _, i ->
                start(devices[i])
            }.show()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) pickDevice()
    }

    private fun start(device: BluetoothDevice) {
        pollJob?.cancel()
        info.text = "Підключення..."
        pollJob = lifecycleScope.launch {
            try {
                val supported = withContext(Dispatchers.IO) {
                    client.connect(device)
                    client.supportedPids()
                }
                val header = "Підтримувані PID: ${supported.sorted().joinToString(" ")}\n\n"
                while (isActive) {
                    val text = withContext(Dispatchers.IO) { readAll() }
                    info.text = header + text
                    delay(1000)
                }
            } catch (e: Exception) {
                info.text = "Помилка: ${e.message}"
            }
        }
    }

    private fun readAll(): String {
        val rpm = client.rpm()
        val speed = client.speedKmh()
        val coolant = client.coolantC()
        val load = client.loadPercent()
        val fuelLph = client.fuelRateLph()

        val consumption = when {
            fuelLph == null -> "н/д (авто не віддає PID 5E)"
            speed == null || speed < 5 -> "%.1f л/год".format(fuelLph)
            else -> "%.1f л/100 км".format(fuelLph / speed * 100)
        }
        return buildString {
            appendLine("Оберти: ${rpm?.toInt() ?: "н/д"}")
            appendLine("Швидкість: ${speed ?: "н/д"} км/год")
            appendLine("Температура ОЖ: ${coolant ?: "н/д"} °C")
            appendLine("Навантаження: ${load?.let { "%.0f %%".format(it) } ?: "н/д"}")
            appendLine("Розхід: $consumption")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        pollJob?.cancel()
        client.close()
    }
}
