package com.example.obdstarter

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/** Мінімальний клієнт ELM327 по Bluetooth SPP. */
class ObdClient {
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice) {
        val s = device.createRfcommSocketToServiceRecord(SPP_UUID)
        s.connect()
        socket = s
        input = s.inputStream
        output = s.outputStream
        for (cmd in listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0")) {
            send(cmd)
        }
    }

    fun close() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
    }

    /** Надсилає команду й читає відповідь до символу '>'. */
    @Synchronized
    fun send(cmd: String, timeoutMs: Long = 4000): String {
        val out = output ?: error("Не підключено")
        val inp = input ?: error("Не підключено")
        out.write((cmd + "\r").toByteArray())
        out.flush()
        val sb = StringBuilder()
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs) {
            if (inp.available() > 0) {
                val c = inp.read().toChar()
                if (c == '>') break
                sb.append(c)
            } else {
                Thread.sleep(10)
            }
        }
        return sb.toString().replace("\r", "\n").trim()
    }

    /** Повертає байти даних для PID режиму 01 або null, якщо блок не відповів. */
    fun readPid(pid: String): IntArray? {
        val raw = send("01$pid")
        val header = "41$pid"
        for (line in raw.lines()) {
            val clean = line.replace(" ", "").uppercase()
            val idx = clean.indexOf(header)
            if (idx >= 0) {
                val hex = clean.substring(idx + header.length)
                if (hex.length < 2) return null
                return hex.chunked(2).filter { it.length == 2 }
                    .mapNotNull { it.toIntOrNull(16) }.toIntArray()
            }
        }
        return null // NO DATA, UNABLE TO CONNECT тощо
    }

    /** Список PID режиму 01, які підтримує блок керування (00, 20, 40, 60...). */
    fun supportedPids(): Set<String> {
        val result = mutableSetOf<String>()
        var base = 0
        while (base <= 0xC0) {
            val pid = "%02X".format(base)
            val data = readPid(pid) ?: break
            if (data.size < 4) break
            val mask = ((data[0].toLong() shl 24) or (data[1].toLong() shl 16) or
                    (data[2].toLong() shl 8) or data[3].toLong())
            for (i in 0 until 32) {
                if (mask and (1L shl (31 - i)) != 0L) {
                    result.add("%02X".format(base + i + 1))
                }
            }
            // останній біт каже, чи є наступний блок PID
            if (mask and 1L == 0L) break
            base += 0x20
        }
        return result
    }

    fun rpm(): Double? = readPid("0C")?.takeIf { it.size >= 2 }?.let { (it[0] * 256 + it[1]) / 4.0 }
    fun speedKmh(): Int? = readPid("0D")?.firstOrNull()
    fun coolantC(): Int? = readPid("05")?.firstOrNull()?.let { it - 40 }
    fun loadPercent(): Double? = readPid("04")?.firstOrNull()?.let { it * 100.0 / 255.0 }
    fun mafGramsPerSec(): Double? = readPid("10")?.takeIf { it.size >= 2 }?.let { (it[0] * 256 + it[1]) / 100.0 }

    /** Витрата палива, л/год (PID 5E). Багато авто 2007 року його не віддають. */
    fun fuelRateLph(): Double? = readPid("5E")?.takeIf { it.size >= 2 }?.let { (it[0] * 256 + it[1]) / 20.0 }

    fun readDtcs(): List<String> {
        val raw = send("03")
        val hex = raw.lines().joinToString("") { it.replace(" ", "").uppercase() }
            .replace("43", "", ignoreCase = false)
        val codes = mutableListOf<String>()
        var i = 0
        while (i + 4 <= hex.length) {
            val chunk = hex.substring(i, i + 4)
            i += 4
            if (chunk == "0000") continue
            val first = chunk[0].digitToIntOrNull(16) ?: continue
            val letter = "PCBU"[first shr 2]
            val digit1 = first and 3
            codes.add("$letter$digit1${chunk.substring(1)}")
        }
        return codes
    }

    companion object {
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }
}
